# Unisa
An e-learning content system based on a storyline concept. The storyline concept defines a flow and taxonomy of learning content which can include number of primitive or composite assets. These assets can include multimedia, learning content as static HTML pages, interactive graphs, LTI components and other storyline components.
