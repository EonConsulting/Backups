<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//namespace UNISAStoryLine\PHPStencilComponent\Controllers;

/**
 * This is a View Render Engine, client view render 
 * this serves only as an interface to all view types e.g soatypeofview.php
 *
 * @author User
 */
Interface ViewRenderRequest 
{
    public function getProperties();
}
