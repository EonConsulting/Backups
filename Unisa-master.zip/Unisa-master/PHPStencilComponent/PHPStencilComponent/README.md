The Stencil serves as a Guideline or starting point to creating the needed L5.3 Package, The Objective is to have a fully working Stencil that utilised Tsugi's Methods as a Vendor or Service provider within the Framework.

The Package should be created Independed but within the Laravel Framework.

An Example could be creating a folder packages within the root of the Laravel install :

App
Packages
	<packagename/package>
		/src
			/Controllers
			/Models
			/Views
			composer.json

To implement structured methods that provide the consumer and provider some predefined relationship via a consumer key and shared secret that are used to sign any messages passed between systems. 