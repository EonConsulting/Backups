# PlagiarismChecker

The was based on the [PHP Package Stencil Wiki](https://github.com/EonConsulting/PackageStencil/wiki)