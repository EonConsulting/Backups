<?php

namespace EONConsulting\PlagiarismChecker;

/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/22/2016
 * Time: 11:47 AM
 */
class PlagiarismChecker {



}