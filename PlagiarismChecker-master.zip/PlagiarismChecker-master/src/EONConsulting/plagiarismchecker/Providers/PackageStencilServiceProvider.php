<?php

namespace EONConsulting\PlagiarismChecker\Providers;

use EONConsulting\PlagiarismChecker\PlagiarismChecker;
use Illuminate\Support\ServiceProvider;

/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/22/2016
 * Time: 11:55 AM
 */
class PlagiarismCheckerServiceProvider extends ServiceProvider {

    /**
     * @return void
     */
    public function boot() {
        $this->loadViewsFrom(__DIR__.'/../Views', 'plagiarismchecker');
    }

    /**
     *  Register the service provider
     */
    public function register() {
        $this->app->singleton('plagiarismchecker', function($app) {
            return new PlagiarismChecker;
        });
    }

}