<?php
namespace EONConsulting\PackageStencil\Factories\Text;

/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/23/2016
 * Time: 9:05 AM
 */
class XMLAdapter implements TextAdapterInterface {

    /**
     * Output the data in XML
     * @param $data
     * @return string
     */
    public function output($data) {
        $xml = new \SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><data></data>');
        $this->arrayToXml($data, $xml);
        return htmlentities($xml->asXML());
    }

    /**
     * Convert the array into XML.
     * @param $data
     * @param $xml_data
     */
    function arrayToXml( $data, &$xml_data) {
        foreach( $data as $key => $value ) {
            if( is_numeric($key) ){
                $key = 'item'.$key; //dealing with <0/>..<n/> issues
            }
            if( is_array($value) ) {
                $subnode = $xml_data->addChild($key);
                $this->arrayToXml($value, $subnode);
            } else {
                $xml_data->addChild("$key",htmlspecialchars("$value"));
            }
        }
    }

}