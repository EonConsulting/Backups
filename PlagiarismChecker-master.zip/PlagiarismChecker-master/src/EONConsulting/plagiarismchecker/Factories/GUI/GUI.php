<?php

namespace EONConsulting\PackageStencil\Factories\GUI;

/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/23/2016
 * Time: 11:15 AM
 */
class GUI {

    protected $adapter;

    /**
     * GUI constructor.
     * @param $adapter
     */
    public function __construct($adapter) {

        // get the set adapter for the different type of view needed
        $this->adapter = $adapter;
    }

    /**
     * Output the data with the correct view
     * @param $data
     * @return mixed
     */
    public function render($data) {
        return view($this->adapter->getGUIName($data), $data);
    }

}