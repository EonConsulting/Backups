<?php

namespace EONConsulting\PackageStencil\Factories\GUI;

/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/23/2016
 * Time: 11:45 AM
 */
class ListAdapter implements GUIAdapterInterface {

    /**
     * Get the name of the view
     * @return string
     */
    public function getGUIName() {
        return 'packagestencil::list';
    }

}