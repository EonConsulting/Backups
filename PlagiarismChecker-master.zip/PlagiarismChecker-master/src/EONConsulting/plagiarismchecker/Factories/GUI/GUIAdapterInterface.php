<?php

namespace EONConsulting\PackageStencil\Factories\GUI;

/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/23/2016
 * Time: 11:16 AM
 */
interface GUIAdapterInterface {

    public function getGUIName();

}