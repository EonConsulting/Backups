<?php

namespace EONConsulting\PackageStencil\Factories\GUI;

/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/23/2016
 * Time: 11:14 AM
 */
class GUIEnum {

    const FORM = 'FORM';
    const UILIST = 'LIST'; // LIST is a keyword

    /**
     * carry on the sequence if you need to add more GUI TYPES here...
     */

    // const NEW_TYPE = 'NEW_TYPE';

}