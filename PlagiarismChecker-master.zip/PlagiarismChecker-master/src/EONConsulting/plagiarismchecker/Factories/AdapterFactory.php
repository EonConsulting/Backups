<?php

namespace EONConsulting\PackageStencil\Factories;

use EONConsulting\PackageStencil\Factories\GUI\FormAdapter;
use EONConsulting\PackageStencil\Factories\GUI\GUIEnum;
use EONConsulting\PackageStencil\Factories\GUI\ListAdapter;
use EONConsulting\PackageStencil\Factories\Text\CSVAdapter;
use EONConsulting\PackageStencil\Factories\Text\JSONAdapter;
use EONConsulting\PackageStencil\Factories\Text\TextEnum;
use EONConsulting\PackageStencil\Factories\Text\XMLAdapter;

/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/23/2016
 * Time: 8:49 AM
 */
class AdapterFactory {

    /**
     * @param $config -> Of type CONFIG or TEXTENUM
     * @return JSONAdapter|XMLAdapter|CSVAdapter|FormAdapter|ListAdapter
     */
    public function make($config) {

        if($config instanceof Config) {
            switch ($config->get('text.default')) {
                case 'json':
                    return new JSONAdapter;
                    break;
                case 'xml':
                    return new XMLAdapter;
                    break;
                case 'csv':
                    return new CSVAdapter;
            }
            switch ($config->get('gui.default')) {
                case 'form':
                    return new FormAdapter;
                    break;
                case GUIEnum::UILIST:
                    return new ListAdapter;
            }
        } else {
            switch ($config) {
                case TextEnum::JSON:
                    return new JSONAdapter;
                    break;
                case TextEnum::XML:
                    return new XMLAdapter;
                    break;
                case TextEnum::CSV:
                    return new CSVAdapter;
                case GUIEnum::FORM:
                    return new FormAdapter;
                case GUIEnum::UILIST:
                    return new ListAdapter;
            }
        }
    }

}