<?php

namespace EONConsulting\PackageStencil\Factories\WebServices;

use EONConsulting\PackageStencil\Factories\AdapterFactory;
use EONConsulting\PackageStencil\Factories\Factory;

/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/23/2016
 * Time: 11:57 AM
 */
class WebServiceFactory implements Factory {

    protected $adapter;

    /**
     * WebServiceFactory constructor.
     * @param AdapterFactory $adapter
     */
    public function __construct(AdapterFactory $adapter) {
        $this->adapter = $adapter;
    }

    /**
     * Return a new WebService object with the correct adapter
     * @param $config
     * @return WebService
     */
    public function make($config) {
        return new WebService($this->adapter->make($config));
    }

}