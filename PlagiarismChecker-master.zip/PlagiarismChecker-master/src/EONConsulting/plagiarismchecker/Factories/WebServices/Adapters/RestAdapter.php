<?php
namespace EONConsulting\PackageStencil\Factories\WebServices;

/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/23/2016
 * Time: 11:59 AM
 */
class RestAdapter implements WebServiceAdapterInterface {

    public function output($data) {

    }

}