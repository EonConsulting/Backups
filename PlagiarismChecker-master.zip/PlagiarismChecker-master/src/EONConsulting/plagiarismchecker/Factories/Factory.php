<?php

namespace EONConsulting\PackageStencil\Factories;

/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/23/2016
 * Time: 8:47 AM
 */
interface Factory {

    public function make($config);

}