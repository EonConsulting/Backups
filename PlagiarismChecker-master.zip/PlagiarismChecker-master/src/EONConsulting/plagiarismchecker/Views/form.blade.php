<?php
echo 'This is the form view';
dd($data);