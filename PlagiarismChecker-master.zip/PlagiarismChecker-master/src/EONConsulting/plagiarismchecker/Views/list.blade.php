<?php
echo 'This is the list view';
dd($data);