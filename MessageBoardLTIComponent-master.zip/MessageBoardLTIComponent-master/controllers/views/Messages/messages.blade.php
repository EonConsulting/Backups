@extends('Layouts.app')
@section('content')
    <div class="panel panel-primary">
        <div class="panel-body panel-default">
            <form action="url{{'messageboard'}}" method="post" class="form-horizontal">
                <div class="form-group row">
                    <label class="col-sm-3 control-label label-primary" for="message">LTI Component Message List</label>
                    <div class="col-sm-12">
                        <input type="text" name="message" id="message" class="form-control"/>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-3 control-label label-primary" for="message">LTI Component Message List</label>
                    <div class="col-sm-12">
                        <input type="text" name="message" id="message" class="form-control"/>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-3 control-label label-primary" for="message">LTI Component Message List</label>
                    <div class="col-sm-12">
                        <input type="text" name="message" id="message" class="form-control"/>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-3 control-label label-primary" for="message">LTI Component Message List</label>
                    <div class="col-sm-12">
                        <input type="text" name="message" id="message" class="form-control"/>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-offset-3 col-sm-6">
                    <button type="submit" class="btn btn-outline-primary">Add to Message Board</button>
                    </div>
                </div>
                {{ csrf_field() }}
            </form>
<!--            --><?php //ob_start();
//            foreach($launch->user as $lunchee) {
//            if ($lunchee->instructor) {
//            echo("<pre>\n");
//            echo("\nLaunch:\n");
//            var_dump($launch);
//            /*
//                    echo("\nSession:\n");
//                    var_dump($request->session());
//                    echo("\nPost:\n");
//                    var_dump($_POST);
//
//                    global $CFG;
//                    echo("\nCFG:\n");
//                    var_dump($CFG);
//            */
//            echo("</pre>\n");
//            return ob_get_clean();
//
//            $input = LTIX::all();
//            var_dump($input);
//            } else {
//            echo 'You can not view Dump';
//            }}
//            ?>
        </div>

    </div>
@endsection