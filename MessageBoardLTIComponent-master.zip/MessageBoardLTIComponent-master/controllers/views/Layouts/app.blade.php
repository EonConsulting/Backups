
<head>
    <!-- To Use a CDN on Implementation -->
    <link type="text/css" rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}"
</head>
<body>
<div class="container">
    @yield('content')
</div>
</body>
