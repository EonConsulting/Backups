<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMessagesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::dropIfExists('messages');

        Schema::create('messages', function (Blueprint $table) {
        $table->integer('link_id');
        $table->integer('user_id');
        $table->text('message')->unique();
        $table->string('ipaddr')->unique();
        $table->timestamps();
        $table->unique(['link_id', 'user_id', 'message']);
        $table->engine = 'InnoDB';
        $table->foreign('link_id')
                ->references('link_id')->on('lti_link')
                ->onDelete('cascade');
        $table->foreign('user_id')
            ->references('user_id')->on('lti_user')
            ->onDelete('cascade');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('messages');
    }
}
