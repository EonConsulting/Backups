<?php
/**
 * Created by PhpStorm.
 * User: Peace Ngara
 * Date: 11/27/2016
 * Time: 12:15 AM
 */

namespace App\Http\Controllers;
use Dotenv\Validator;
use Illuminate\Contracts\View\View;
use Illuminate\Routing\Controller as BaseController;
use EONConsulting\MessageBoard\Factories\GUI\GUIEnum;
use EONConsulting\MessageBoard\Factories\GUI\GUIFactory;
use EONConsulting\MessageBoard\Factories\Text\TextEnum;
use EONConsulting\MessageBoard\Factories\Text\TextFactory;
use EONConsulting\MessageBoard\Factories\AdapterFactory;

require_once app_path() ."/../config.php";

use Illuminate\Http\Request;
use Tsugi\Laravel\LTIX;

class MessageController extends BaseController
{

    public function sayMessage(Request $request) {

        return View('Messages.messages')->with('$launch');
        //return messageboard()->render('messages.messages', ["hello_message" => "Hello GUI"]);
        //var_dump(messageboard()->render('messages.messages',["hello_message" => "Hello GUI"]));

    }
    /*
     * Create a New Instance of the LTIX Launcher or new session
     * @return true
     */
    public function createMessage(Request $request) {
        /*
         * Typehinted the Requested Property
         * @param $request
         */
        $launch = LTIX::laravelSetup($request, LTIX::ALL);
        if ( $launch->redirect_url ) return redirect($launch->redirect_url);
        if ( $launch->send_403 ) return response($launch->error_message, 403);

        ob_start();
        if ($launch->user->instructor) {
            echo("<pre>\n");
            echo("\nLaunch:\n");
            var_dump($launch);
            /*
                    echo("\nSession:\n");
                    var_dump($request->session());
                    echo("\nPost:\n");
                    var_dump($_POST);

                    global $CFG;
                    echo("\nCFG:\n");
                    var_dump($CFG);
            */
            echo("</pre>\n");
            return ob_get_clean();

            $input = LTIX::all();
            var_dump($input);
        } else {
            $displayname = $launch->user->displayname. ",&nbsp;You don't have sufficient privileges to View this Page";
            $displayname .= "<hr>";
            echo $displayname;

        }//$validator = Validator make();
        //dd($request);
    }
}