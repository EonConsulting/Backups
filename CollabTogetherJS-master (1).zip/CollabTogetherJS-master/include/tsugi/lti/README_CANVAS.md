
This makes an old-style Canvas registry

https://lti-tools.dr-chuck.com/tsugi/lti/canvas-content-item-xml.php

