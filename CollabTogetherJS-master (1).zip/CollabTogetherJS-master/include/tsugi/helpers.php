<?php
/**
 * Created by PhpStorm.
 * User: jharing10
 * Date: 2016/12/18
 * Time: 11:20 PM
 */

if(!function_exists('tsugi')) {
    function tsugi() {
        return app('tsugi');
    }
}