For now I made simple badges using

https://www.openbadges.me/designer.html


