
Using this with Canvas
----------------------

To install this as an "app store" in Canvas.  Install an "App" using
the "By URL" pattern, enter this URL adapted to your path:

   https://lti-tools.dr-chuck.com/tsugi/lti/store/canvas-config.xml

You also need an LTI 1.x key/secret in the Tsugi instance as well.


