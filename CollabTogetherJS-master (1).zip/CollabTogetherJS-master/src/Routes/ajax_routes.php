<?php
/**
 * Routes for the Collaboration Package
 */
Route::group(['namespace' => 'EONConsulting\Collab\src\Http\Controllers', 'prefix' => '/_eon_ajax/collab/'], function() {

    Route::group(['prefix' => 'channels'], function() {
        Route::post('/create', ['as' => 'collab.channels.create', 'uses' => 'ChannelController@create']);
        Route::get('/', ['as' => 'collab.channels.list', 'uses' => 'ChannelController@list_all']);
    });

    Route::group(['prefix' => 'members'], function() {
        Route::post('/create', ['as' => 'collab.members.create', 'uses' => 'MemberController@create']);
        Route::get('/', ['as' => 'collab.members.list', 'uses' => 'MemberController@list_all']);
        Route::post('/leave', ['as' => 'collab.members.update', 'uses' => 'MemberController@left_room']);
    });

    /**
     *  PLACE YOUR ROUTES HERE
     */

});