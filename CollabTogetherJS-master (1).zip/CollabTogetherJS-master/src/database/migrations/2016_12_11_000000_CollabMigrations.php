<?php

/**
 * Class CollabMigrations
 */
class CollabMigrations extends \Illuminate\Database\Migrations\Migration  {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        \Illuminate\Support\Facades\Schema::create('channels', function (\Illuminate\Database\Schema\Blueprint $table) {
            $table->increments('channel_id');
            $table->string('channel');
            $table->integer('active');
            $table->timestamps();
        });
        \Illuminate\Support\Facades\Schema::create('channel_members', function (\Illuminate\Database\Schema\Blueprint $table) {
            $table->increments('channel_member_id');
            $table->integer('channel_id');
            $table->string('member_id');
            $table->string('ip_address');
            $table->integer('active');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        \Illuminate\Support\Facades\Schema::drop('channels');
        \Illuminate\Support\Facades\Schema::drop('channel_members');
    }

}