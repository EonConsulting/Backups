<?php

namespace EONConsulting\Collab\src\Models;


use Illuminate\Database\Eloquent\Model;

/**
 * Class Channel (Model)
 * @package EONConsulting\Collab\src\Models
 */
class Channel extends Model {

    protected $table = 'channels';
    protected $primaryKey = 'channel_id';
    protected $fillable = ['channel', 'active'];

}