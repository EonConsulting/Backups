<?php

namespace EONConsulting\Collab\src\Models;


use Illuminate\Database\Eloquent\Model;

/**
 * Class ChannelMember (Model)
 * @package EONConsulting\Collab\src\Models
 */
class ChannelMember extends Model {

    protected $table = 'channel_members';
    protected $primaryKey = 'channel_member_id';
    protected $fillable = ['channel_id', 'member_no', 'ip_address', 'active'];

}