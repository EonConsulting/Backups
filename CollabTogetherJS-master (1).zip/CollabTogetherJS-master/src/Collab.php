<?php

namespace EONConsulting\Collab;

/**
 * Class Collab
 * @package EONConsulting\Collab
 */
class Collab {

    /**
     * Default Collaborate View
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function collaborate() {
        return view('collab::collaborate');
    }

    /**
     * Contact Form Demo
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function demo_contact_form() {
        return view('collab::contact-form');
    }

    /**
     * Menu Demo
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function demo_menu() {
        return view('collab::menu-demo');
    }

}