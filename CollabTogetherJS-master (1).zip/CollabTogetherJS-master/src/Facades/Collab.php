<?php

namespace EONConsulting\Collab\src\Facades;


use Illuminate\Support\Facades\Facade;

/**
 * Class Collab
 * @package EONConsulting\Collab\src\Facades
 */
class Collab extends Facade {

    /**
     * Create the Facade
     * @return string
     */
    public static function getFacadeAccessor() {
        return 'collab';
    }

}