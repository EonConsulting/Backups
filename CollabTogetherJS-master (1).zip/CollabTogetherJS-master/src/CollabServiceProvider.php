<?php

namespace EONConsulting\Collab;

use Illuminate\Support\ServiceProvider;

/**
 * Class CollabServiceProvider
 * @package EONConsulting\Collab
 */
class CollabServiceProvider extends ServiceProvider {

    /**
     * Register the service provider.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind( 'collab', function () {
            return new Collab();
        });
    }

    /**
     * Boot the service provider
     */
    public function boot()
    {
        $this->loadRoutesFrom(__DIR__.'/Routes/ajax_routes.php');
        $this->loadViewsFrom(__DIR__ . '/resources/views', 'collab');

        $this->publishes([
            __DIR__ . '/database/migrations' => $this->app->databasePath() . '/migrations'
        ], 'migrations');
    }
}