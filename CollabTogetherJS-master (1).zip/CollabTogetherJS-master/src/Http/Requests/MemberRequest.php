<?php

namespace EONConsulting\Collab\src\Http\Requests;


use Illuminate\Foundation\Http\FormRequest;

/**
 * Class MemberRequest
 * @package EONConsulting\Collab\src\Http\Requests
 */
class MemberRequest extends FormRequest {

    /**
     * Authorize the request
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Rules for the request
     * @return array
     */
    public function rules() {
        return [
            'channel' => 'required',
            'client_id' => 'required'
        ];
    }

}