<?php

namespace EONConsulting\Collab\src\Http\Controllers;


use App\Http\Controllers\Controller;
use EONConsulting\Collab\src\Http\Requests\CreateCollabRequest;
use EONConsulting\Collab\src\Models\Channel;
use EONConsulting\Collab\src\Models\ChannelMember;

/**
 * Class CollabController
 * @package EONConsulting\Collab\src\Http\Controllers
 */
class CollabController extends Controller {

    /**
     * Create a new Channel
     * @param CreateCollabRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function create(CreateCollabRequest $request) {
        $share_id = $request->get('channel');
        $client_id = $request->get('client_id');
        $ip = $request->ip();

        $channel = Channel::firstOrNew([
            'channel' => $share_id
        ]);

        $channel->active = 1;
        $channel->save();

        $member = ChannelMember::firstOrNew([
            'channel_id' => $channel->channel_id,
            'ip_address' => $ip
        ]);
        $member->member_no = $client_id;
        $member->active = 1;
        $member->save();

        return response()->json(['success' => true, 'data' => ['success' => true, 'channel' => $channel, 'member' => $member, 'success_message' => 'Channel created.']]);
    }

    /**
     * List all the channels
     * @return \Illuminate\Http\JsonResponse
     */
    public function list_all() {
        $channels = Channel::where('active', 1)->get();

        return response()->json(['success' => true, 'data' => ['success' => true, 'channels' => $channels]]);
    }

}