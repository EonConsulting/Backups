<?php

namespace EONConsulting\Collab\src\Http\Controllers;


use App\Http\Controllers\Controller;
use EONConsulting\Collab\src\Http\Requests\MemberRequest;
use EONConsulting\Collab\src\Models\Channel;
use EONConsulting\Collab\src\Models\ChannelMember;
use Illuminate\Http\Request;

/**
 * Class MemberController
 * @package EONConsulting\Collab\src\Http\Controllers
 */
class MemberController extends Controller {

    /**
     * Register as a member of a channel
     * @param MemberRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function create(MemberRequest $request) {
        $share_id = $request->get('channel');
        $client_id = $request->get('client_id');
        $ip = $request->ip();

        $channel = Channel::where('channel', $share_id)->first();

        $member = ChannelMember::firstOrNew([
            'channel_id' => $channel->channel_id,
            'ip_address' => $ip
        ]);
        $member->member_no = $client_id;
        $member->active = 1;
        $member->save();

        return response()->json(['success' => true, 'data' => ['success' => true, 'channel' => $channel, 'member' => $member, 'success_message' => 'Member created.']]);
    }

    /**
     * Leave a channel
     * @param MemberRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function left_room(MemberRequest $request) {
        $share_id = $request->get('channel');
        $client_id = $request->get('client_id');

        $channel = Channel::where('channel', $share_id)->first();

        ChannelMember::where('channel_id', $channel->channel_id)->where('member_no', $client_id)->update(['active' => 0]);

        $member_count = ChannelMember::where('channel_id', $channel->channel_id)->where('active', 1)->get();
        if($member_count == 0) {
            $channel->active = 0;
            $channel->save();
        }

        return response()->json(['success' => true, 'data' => ['success' => true, 'channel' => $channel, 'success_message' => 'Member left channel.']]);
    }

    /**
     * List all members in a channel
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function list_all(Request $request) {
        $share_id = $request->get('channel');

        $channel = Channel::where('channel', $share_id)->first();

        $members = [];

        if($channel)
            $members = ChannelMember::where('channel_id', $channel->channel_id)->get();

        return response()->json(['success' => true, 'data' => ['success' => true, 'channel' => $channel, 'members' => $members]]);
    }

}