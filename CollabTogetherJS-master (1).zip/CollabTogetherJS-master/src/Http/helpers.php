<?php
/**
 * Helper methods for the Collaboration package
 */

if(!function_exists('collab')) {
    /**
     * Register the global function
     * @return \Illuminate\Foundation\Application|mixed
     */
    function collab() {
        return app('collab');
    }
}