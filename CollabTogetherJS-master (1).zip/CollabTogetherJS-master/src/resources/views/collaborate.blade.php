<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <button id="btn_collab" onclick="TogetherJS(this); return false;">Start Collaboration</button>

    <ul id="channels"></ul>

    <script
            src="https://code.jquery.com/jquery-2.2.4.min.js"
            integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="
            crossorigin="anonymous"></script>
    <script src="https://togetherjs.com/togetherjs-min.js"></script>
    <script>
        $(function () {

            var visibilityChangeFromRemote = false;

            var MyApp = TogetherJS;

            $("#start-togetherjs").on('click', function() {
                TogetherJS(this);
            });

            TogetherJSConfig_on = {
                ready: function () {}
            };

            TogetherJSConfig_on_ready = function () {
                MyApp.on("visibilityChange", fireTogetherJSVisibility);
                console.log('on ready');
            };
            TogetherJSConfig_on_close = function () {
                MyApp.off("visibilityChange", fireTogetherJSVisibility);
            };

            function fireTogetherJSVisibility(element, isVisible) {
                if (visibilityChangeFromRemote) {
                    return;
                }
                var elementFinder = TogetherJS.require("elementFinder");
                var location = elementFinder.elementLocation(element);
                TogetherJS.send({type: "visibilityChange", isVisible: isVisible, element: location});
            }

            TogetherJS.hub.on("visibilityChange", function (msg) {
                var elementFinder = TogetherJS.require("elementFinder");
                // If the element can't be found this will throw an exception:
                var element = elementFinder.findElement(msg.element);
                MyApp.changeVisibility(element, msg.isVisible);
            });

            TogetherJS.hub.on("togetherjs.init-connection", function (msg) {
                //var session = TogetherJS.require("session");
                //var peers = TogetherJS.require('peers');
                console.log('session', session);
                console.log('peers', peers.getAllPeers());
                $('#btn_collab').html('Stop Collaboration');
            });

            TogetherJS.hub.on("togetherjs.hello", function (msg) {
                if (! msg.sameUrl) {
                    return;
                }
                MyApp.allToggleElements.forEach(function (el) {
                    var isVisible = $(el).is(":visible");
                    fireTogetherJSVisibility(el, isVisible);
                });
            });

            TogetherJS.hub.on("togetherjs.bye", function (msg) {
                var session = TogetherJS.require("session");
                console.log('session', session);
                $('#btn_collab').html('Start Collaboration');

            });

            $.fn.syncShow = function () {
                this.show();
                this.trigger("visibilityChange");
            };

            $.fn.syncHide = function () {
                this.hide();
                this.trigger("visibilityChange");
            };

            $(document).on("visibilityChange", function () {
                MyApp.emit("visibilityChange", this, $(this).is(":visible"));
            });

            MyApp.changeVisibility = function (el, isVisible) {
                if (isVisible && ! el.is(":visible")) {
                    el.syncShow();
                } else if ((! isVisible) && el.is(":visible")) {
                    el.syncHide();
                }
            };

        });
    </script>
</body>
</html>