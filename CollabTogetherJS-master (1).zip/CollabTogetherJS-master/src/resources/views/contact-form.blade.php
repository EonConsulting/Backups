<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Collaboration with a Form</title>

    <style>
        @import url(http://fonts.googleapis.com/css?family=Merriweather);
        *,
        *:before,
        *:after {
            -moz-box-sizing: border-box;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
        }

        html,
        body {
            background: #f1f1f1;
            font-family: 'Merriweather', sans-serif;
            padding: 1em;
        }

        h1 {
            text-align: center;
            color: #a8a8a8;
            text-shadow: 1px 1px 0 white;
        }

        form {
            max-width: 600px;
            text-align: center;
            margin: 20px auto;
        }
        form input,
        form textarea {
            border: 0;
            outline: 0;
            padding: 1em;
            -moz-border-radius: 8px;
            -webkit-border-radius: 8px;
            border-radius: 8px;
            display: block;
            width: 100%;
            margin-top: 1em;
            font-family: 'Merriweather', sans-serif;
            -moz-box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
            -webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
            box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
            resize: none;
        }
        form input:focus,
        form textarea:focus {
            -moz-box-shadow: 0 0px 2px #e74c3c !important;
            -webkit-box-shadow: 0 0px 2px #e74c3c !important;
            box-shadow: 0 0px 2px #e74c3c !important;
        }
        form #input-submit {
            color: white;
            background: #e74c3c;
            cursor: pointer;
        }
        form #input-submit:hover {
            -moz-box-shadow: 0 1px 1px 1px rgba(170, 170, 170, 0.6);
            -webkit-box-shadow: 0 1px 1px 1px rgba(170, 170, 170, 0.6);
            box-shadow: 0 1px 1px 1px rgba(170, 170, 170, 0.6);
        }
        form textarea {
            height: 126px;
        }

        .half {
            float: left;
            width: 48%;
            margin-bottom: 1em;
        }

        .right {
            width: 50%;
        }

        .left {
            margin-right: 2%;
        }

        @media (max-width: 480px) {
            .half {
                width: 100%;
                float: none;
                margin-bottom: 0;
            }
        }
        /* Clearfix */
        .cf:before,
        .cf:after {
            content: " ";
            /* 1 */
            display: table;
            /* 2 */
        }

        .cf:after {
            clear: both;
        }

    </style>
</head>
<body>
    <button id="btn_collab" onclick="TogetherJS(this); return false;">Start Collaboration</button>

    <script
            src="https://code.jquery.com/jquery-2.2.4.min.js"
            integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="
            crossorigin="anonymous"></script>
    <script src="https://togetherjs.com/togetherjs-min.js"></script>
    <h1>Elegant Contact Form</h1>
    <form class="cf">
        <div class="half left cf">
            <input type="text" id="input-name" placeholder="Name">
            <input type="email" id="input-email" placeholder="Email address">
            <input type="text" id="input-subject" placeholder="Subject">
        </div>
        <div class="half right cf">
            <textarea name="message" type="text" id="input-message" placeholder="Message"></textarea>
        </div>
        <input type="submit" value="Submit" id="input-submit">
    </form>

    <script>
       $(function () {

            var visibilityChangeFromRemote = false;

            var MyApp = TogetherJS;

            $("#start-togetherjs").on('click', function() {
                TogetherJS(this);
            });

            TogetherJSConfig_on = {
                ready: function () {}
            };

            TogetherJSConfig_on_ready = function () {
                MyApp.on("visibilityChange", fireTogetherJSVisibility);
                console.log('on ready');
            };
            TogetherJSConfig_on_close = function () {
                MyApp.off("visibilityChange", fireTogetherJSVisibility);
            };

            function fireTogetherJSVisibility(element, isVisible) {
                if (visibilityChangeFromRemote) {
                    return;
                }
                var elementFinder = TogetherJS.require("elementFinder");
                var location = elementFinder.elementLocation(element);
                TogetherJS.send({type: "visibilityChange", isVisible: isVisible, element: location});
            }

            TogetherJS.hub.on("visibilityChange", function (msg) {
                var elementFinder = TogetherJS.require("elementFinder");
                // If the element can't be found this will throw an exception:
                var element = elementFinder.findElement(msg.element);
                MyApp.changeVisibility(element, msg.isVisible);
            });

            TogetherJS.hub.on("togetherjs.init-connection", function (msg) {
                //var session = TogetherJS.require("session");
                //var peers = TogetherJS.require('peers');
                $('#btn_collab').html('Stop Collaboration');
            });

            TogetherJS.hub.on("togetherjs.hello", function (msg) {
                if (! msg.sameUrl) {
                    return;
                }
                MyApp.allToggleElements.forEach(function (el) {
                    var isVisible = $(el).is(":visible");
                    fireTogetherJSVisibility(el, isVisible);
                });
            });

            TogetherJS.hub.on("togetherjs.bye", function (msg) {
                var session = TogetherJS.require("session");
                console.log('session', session);
                $('#btn_collab').html('Start Collaboration');

            });

            $.fn.syncShow = function () {
                this.show();
                this.trigger("visibilityChange");
            };

            $.fn.syncHide = function () {
                this.hide();
                this.trigger("visibilityChange");
            };

            $(document).on("visibilityChange", function () {
                MyApp.emit("visibilityChange", this, $(this).is(":visible"));
            });

            MyApp.changeVisibility = function (el, isVisible) {
                if (isVisible && ! el.is(":visible")) {
                    el.syncShow();
                } else if ((! isVisible) && el.is(":visible")) {
                    el.syncHide();
                }
            };

        });
    </script>
</body>
</html>