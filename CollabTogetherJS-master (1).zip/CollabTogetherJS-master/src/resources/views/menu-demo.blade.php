<!DOCTYPE html>
<html lang="en" class="no-js">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Collaborate with a Menu</title>
    <!-- food icons -->
    <link rel="stylesheet" type="text/css" href="http://thereformationcontinues.com/eon-demo/css/organicfoodicons.css" />
    <!-- demo styles -->
    <link rel="stylesheet" type="text/css" href="http://thereformationcontinues.com/eon-demo/css/demo.css" />
    <!-- menu styles -->
    <link rel="stylesheet" type="text/css" href="http://thereformationcontinues.com/eon-demo/css/component.css" />
    <script src="http://thereformationcontinues.com/eon-demo/js/modernizr-custom.js"></script>
</head>

<body>
<!-- Main container -->
<div class="container">
    <!-- Blueprint header -->
    <header class="bp-header cf">
        <div class="dummy-logo">
            <div class="dummy-icon foodicon foodicon--coconut"></div>
            <h2 class="dummy-heading">Menu Demo</h2>
        </div>
        <div class="bp-header__main">
            <h1 class="bp-header__title">Multi-Level Menu</h1>
            <button id="btn_collab" onclick="TogetherJS(this); return false;">Start Collaboration</button>
        </div>
    </header>
    <button class="action action--open" aria-label="Open Menu"><span class="icon icon--menu"></span></button>
    <nav id="ml-menu" class="menu">
        <button class="action action--close" aria-label="Close Menu"><span class="icon icon--cross"></span></button>
        <div class="menu__wrap">
            <ul data-menu="main" class="menu__level">
                <li class="menu__item"><a class="menu__link" data-submenu="submenu-1" href="#">Vegetables</a></li>
                <li class="menu__item"><a class="menu__link" data-submenu="submenu-2" href="#">Fruits</a></li>
                <li class="menu__item"><a class="menu__link" data-submenu="submenu-3" href="#">Grains</a></li>
                <li class="menu__item"><a class="menu__link" data-submenu="submenu-4" href="#">Mylk &amp; Drinks</a></li>
            </ul>
            <!-- Submenu 1 -->
            <ul data-menu="submenu-1" class="menu__level">
                <li class="menu__item"><a class="menu__link" href="#">Stalk Vegetables</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Roots &amp; Seeds</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Cabbages</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Salad Greens</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Mushrooms</a></li>
                <li class="menu__item"><a class="menu__link" data-submenu="submenu-1-1" href="#">Sale %</a></li>
            </ul>
            <!-- Submenu 1-1 -->
            <ul data-menu="submenu-1-1" class="menu__level">
                <li class="menu__item"><a class="menu__link" href="#">Fair Trade Roots</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Dried Veggies</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Our Brand</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Homemade</a></li>
            </ul>
            <!-- Submenu 2 -->
            <ul data-menu="submenu-2" class="menu__level">
                <li class="menu__item"><a class="menu__link" href="#">Citrus Fruits</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Berries</a></li>
                <li class="menu__item"><a class="menu__link" data-submenu="submenu-2-1" href="#">Special Selection</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Tropical Fruits</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Melons</a></li>
            </ul>
            <!-- Submenu 2-1 -->
            <ul data-menu="submenu-2-1" class="menu__level">
                <li class="menu__item"><a class="menu__link" href="#">Exotic Mixes</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Wild Pick</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Vitamin Boosters</a></li>
            </ul>
            <!-- Submenu 3 -->
            <ul data-menu="submenu-3" class="menu__level">
                <li class="menu__item"><a class="menu__link" href="#">Buckwheat</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Millet</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Quinoa</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Wild Rice</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Durum Wheat</a></li>
                <li class="menu__item"><a class="menu__link" data-submenu="submenu-3-1" href="#">Promo Packs</a></li>
            </ul>
            <!-- Submenu 3-1 -->
            <ul data-menu="submenu-3-1" class="menu__level">
                <li class="menu__item"><a class="menu__link" href="#">Starter Kit</a></li>
                <li class="menu__item"><a class="menu__link" href="#">The Essential 8</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Bolivian Secrets</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Flour Packs</a></li>
            </ul>
            <!-- Submenu 4 -->
            <ul data-menu="submenu-4" class="menu__level">
                <li class="menu__item"><a class="menu__link" href="#">Grain Mylks</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Seed Mylks</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Nut Mylks</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Nutri Drinks</a></li>
                <li class="menu__item"><a class="menu__link" data-submenu="submenu-4-1" href="#">Selection</a></li>
            </ul>
            <!-- Submenu 4-1 -->
            <ul data-menu="submenu-4-1" class="menu__level">
                <li class="menu__item"><a class="menu__link" href="#">Nut Mylk Packs</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Amino Acid Heaven</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Allergy Free</a></li>
            </ul>
        </div>
    </nav>
    <div class="content">
        <p class="info">Please choose a category</p>
        <!-- Ajax loaded content here -->
    </div>
</div>
<!-- /view -->
<script src="http://thereformationcontinues.com/eon-demo/js/classie.js"></script>
<script src="http://thereformationcontinues.com/eon-demo/js/dummydata.js"></script>
<script src="http://thereformationcontinues.com/eon-demo/js/main.js"></script>
<script
        src="https://code.jquery.com/jquery-2.2.4.min.js"
        integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="
        crossorigin="anonymous"></script>
<script src="https://togetherjs.com/togetherjs-min.js"></script>
<script>
    (function() {
        var menuEl = document.getElementById('ml-menu'),
            mlmenu = new MLMenu(menuEl, {
                // breadcrumbsCtrl : true, // show breadcrumbs
                // initialBreadcrumb : 'all', // initial breadcrumb text
                backCtrl : false, // show back button
                // itemsDelayInterval : 60, // delay between each menu item sliding animation
                onItemClick: loadDummyData // callback: item that doesn´t have a submenu gets clicked - onItemClick([event], [inner HTML of the clicked item])
            });

        // mobile menu toggle
        var openMenuCtrl = document.querySelector('.action--open'),
            closeMenuCtrl = document.querySelector('.action--close');

        openMenuCtrl.addEventListener('click', openMenu);
        closeMenuCtrl.addEventListener('click', closeMenu);

        function openMenu() {
            classie.add(menuEl, 'menu--open');
        }

        function closeMenu() {
            classie.remove(menuEl, 'menu--open');
        }

        // simulate grid content loading
        var gridWrapper = document.querySelector('.content');

        function loadDummyData(ev, itemName) {
            ev.preventDefault();

            closeMenu();
            gridWrapper.innerHTML = '';
            classie.add(gridWrapper, 'content--loading');
            setTimeout(function() {
                classie.remove(gridWrapper, 'content--loading');
                gridWrapper.innerHTML = '<ul class="products">' + dummyData[itemName] + '<ul>';
            }, 700);
        }
    })();

    $(function () {

        var visibilityChangeFromRemote = false;

        var MyApp = TogetherJS;

        $("#start-togetherjs").on('click', function() {
            TogetherJS(this);
        });

        TogetherJSConfig_on = {
            ready: function () {}
        };

        TogetherJSConfig_on_ready = function () {
            MyApp.on("visibilityChange", fireTogetherJSVisibility);
            console.log('on ready');
        };
        TogetherJSConfig_on_close = function () {
            MyApp.off("visibilityChange", fireTogetherJSVisibility);
        };

        function fireTogetherJSVisibility(element, isVisible) {
            if (visibilityChangeFromRemote) {
                return;
            }
            var elementFinder = TogetherJS.require("elementFinder");
            var location = elementFinder.elementLocation(element);
            TogetherJS.send({type: "visibilityChange", isVisible: isVisible, element: location});
        }

        TogetherJS.hub.on("visibilityChange", function (msg) {
            var elementFinder = TogetherJS.require("elementFinder");
            // If the element can't be found this will throw an exception:
            var element = elementFinder.findElement(msg.element);
            MyApp.changeVisibility(element, msg.isVisible);
        });

        TogetherJS.hub.on("togetherjs.init-connection", function (msg) {
            //var session = TogetherJS.require("session");
            //var peers = TogetherJS.require('peers');
            $('#btn_collab').html('Stop Collaboration');
        });

        TogetherJS.hub.on("togetherjs.hello", function (msg) {
            if (! msg.sameUrl) {
                return;
            }
            MyApp.allToggleElements.forEach(function (el) {
                var isVisible = $(el).is(":visible");
                fireTogetherJSVisibility(el, isVisible);
            });
        });

        TogetherJS.hub.on("togetherjs.bye", function (msg) {
            var session = TogetherJS.require("session");
            console.log('session', session);
            $('#btn_collab').html('Start Collaboration');

        });

        $.fn.syncShow = function () {
            this.show();
            this.trigger("visibilityChange");
        };

        $.fn.syncHide = function () {
            this.hide();
            this.trigger("visibilityChange");
        };

        $(document).on("visibilityChange", function () {
            MyApp.emit("visibilityChange", this, $(this).is(":visible"));
        });

        MyApp.changeVisibility = function (el, isVisible) {
            if (isVisible && ! el.is(":visible")) {
                el.syncShow();
            } else if ((! isVisible) && el.is(":visible")) {
                el.syncHide();
            }
        };

    });
</script>
</body>

</html>
