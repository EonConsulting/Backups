<?php
session_start();

//Include functions
include 'function.php';
// check if username session exists
if(isset($_SESSION['username'])){
	?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Edit API - Third Party Application Request</title>
<link href="css/style.css" rel="stylesheet">
</head>
<body>
<p>
<a href='auth.php'><button>Home</button></a><p>

<?php
include "dbconfig.php";

/*for($i=0;$i<$count;$i++){
$sql1="UPDATE cs_app_api SET parameter_name='$parameter_name[$i]', parameter='$parameter[$i]' WHERE id='$id[$i]'";
$result1=mysql_query($sql1);
}*/
$count = $_POST['count'];

	for($i=0;$i<$count;$i++){
		$sql1="UPDATE cs_app_api SET parameter_name='".$_POST['parameter_name'][$i]."', parameter='". $_POST['parameter'][$i]."' WHERE id='".$_POST['id'][$i]."'";
		$result1 = $db->query($sql1);
	}
	
	echo "Updated successfully";

?>  

</body>
</html>
<?php
}
