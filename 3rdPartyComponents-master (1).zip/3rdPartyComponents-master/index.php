<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Third Party Application Request</title>
<link href="css/style.css" rel="stylesheet">
</head>
  <body>
  <center>
  <p>
  <p>
  Welcome, please login with your username and password.
  <p>
  <form action="auth.php" method="post" enctype="multipart/form-data">
    <table>
      <tr>
        <td>Username:</td><td><input type="text" name="username"></td>
      </tr>
      <tr>
        <td>Password:</td><td><input type="password" name="password"></td>
      </tr>
      <tr>
        <td colspan="2" class="dblcol"><input type="submit" value="Submit"></td>
      </tr>
    </table>
  <form>
  <font class="notes">Not yet registered? <a href="registration.php">Click here</a></font>
  </body>
</html>