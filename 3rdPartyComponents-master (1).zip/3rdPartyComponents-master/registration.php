<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<title>Registration</title>
  
    <link href="css/style.css" rel="stylesheet">

</head>
<body>
<center>
<p>
<p>
Welcome, please complete the details below to register.

<p>

<form action="register.php" method="post" enctype="multipart/form-data">
<table>
<tr>
<td>First name: </td><td><input class="input" type="text" name="firstname" style="width:255px; "></td>
</tr>
<tr>
<td>Surname: </td><td><input type="text" name="lastname" style="width:255px; "></td>
</tr>
<tr>
<td>Email Address: </td><td><input type="text" name="email" style="width:255px; "></td>
</tr>
<tr>
<td>Username: </td><td><input type="text" name="username" style="width:255px; "></td>
</tr>
<tr>
<td>Password: </td><td><input type="password" name="password" style="width:255px; "></td>
</tr>
<tr>
<td>Confirm password: </td><td><input type="password" name="confirmpass" style="width:255px; "></td>
</tr>
<tr>
<td colspan=2 class="dblcol" align="center"><input type="submit" value="Submit"></td>
</tr>
</table>
</form>
<font class="notes">Already registered! <a href="index.php">Click here</a></font>
</body>
</html>

<?php


/* notes


*/
