<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>View - Third Party Application Request</title>
    <link href="css/style.css" rel="stylesheet">
	
</head>
<body>
<?php
session_start();
include 'dbconfig.php';
if (isset($_SESSION['username'])){
	echo "<h3>Applications detailed view: </h3>
	<a href='auth.php'><button>Home</button></a> <a href='edit.php?id=".$_GET['id']."'><button>Edit Application Details</button></a> <a href='editapi.php?id=".$_GET['id']."'><button>Edit Application APIs</button></a>
	<h4>Application Details:</h4>";
	echo "<table border='1'>";
	// get destails of applications selected
	$sql="SELECT * FROM cs_app_req WHERE id='".$_GET['id']."'";
	$result = $db->query($sql);
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			// assign known details and get the category names for each category level
			$app_ip = $row['id'];
			$application = $row['title'];
			$description = $row['description'];
			$metadata = $row['metadata'];
			$delivery_url = $row['delivery_url'];
			$hosted_url = $row['hosted_url'];
			$secret = $row['secret'];
			$appkey = $row['appkey'];
			$date_added = $row['date_added'];
			$cat_1 = $row['cat_lvl_1'];
			$cat_2 = $row['cat_lvl_2'];
			$cat_3 = $row['cat_lvl_3'];
			$cat_4 = $row['cat_lvl_4'];
			
			//get category names for each category level
			$sql = "SELECT * FROM cat_1 WHERE cat_1_id='$cat_1'";
			$result = mysqli_query($db,$sql);
			$row=mysqli_fetch_assoc($result);
			$cat_1 = $row['cat_1'];
			
			$sql = "SELECT * FROM cat_2 WHERE cat_2_id='$cat_2'";
			$result = mysqli_query($db,$sql);
			$row=mysqli_fetch_assoc($result);
			$cat_2 = $row['cat_2'];
			
			$sql = "SELECT * FROM cat_3 WHERE cat_3_id='$cat_3'";
			$result = mysqli_query($db,$sql);
			$row=mysqli_fetch_assoc($result);
			$cat_3 = $row['cat_3'];
			
			$sql = "SELECT * FROM cat_4 WHERE cat_4_id='$cat_4'";
			$result = mysqli_query($db,$sql);
			$row=mysqli_fetch_assoc($result);
			$cat_4 = $row['cat_4'];
			
			//display information
			echo "
			<tr><td><b>Application title</b></td><td>$application</td></tr>
			<tr><td><b>Category</b></td><td>$cat_1<br />&#160;&#160;$cat_2<br />&#160;&#160;&#160;&#160;$cat_3<br />&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;$cat_4</td></tr>
			<tr><td><b>Description</b></td><td>$description</td></tr>
			<tr><td><b>Metadata</b></td><td>$metadata</td></tr>
			<tr><td><b>Delivery URL</b></td><td>$delivery_url</td></tr>
			<tr><td><b>Hosted URL</b></td><td>$hosted_url</td></tr>
			<tr><td><b>Secret</b></td><td>$secret</td></tr>
			<tr><td><b>Key</b></td><td>$appkey</td></tr>
			<tr><td><b>Date Added</b></td><td>$date_added</td></tr>
			";
		}
	} else {
		echo "No records found";
	}
	echo "</table>
	<p>&nbsp;
	<p>
	<h4>API Parameters</h4>
	<table>";
	// get destails of applications selected
	$sql="SELECT * FROM cs_app_api WHERE app_id='$app_ip'";
	$result = $db->query($sql);
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			echo "<tr><td><b>Parameter Name</b></td><td>".$row['parameter_name']."</td></tr>
			<tr><td><b>Parameter</b></td><td>".$row['parameter']."</td></tr>
			<tr><td><b>Date added</b></td><td>".$row['date_added']."</td></tr>
			<tr><td colspan=2></td></tr>
			";
		}
	}
	echo "</table>
	";
	
		
} else {
	echo "You are not allowed to view this page";
}