<?php
	session_start();
	if(isset($_POST['username'])){
		$_SESSION['username'] = $_POST['username'];
		$_SESSION['password'] = $_POST['password'];
	}
	
	//Include functions
	include 'function.php';
	// check username and password
	if(isset($_SESSION['username'])){
		CheckPassword();
		?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>User Logged In - Third Party Application Request</title>
<link href="css/style.css" rel="stylesheet">
<script src="jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    $('#cat_1').on('change',function(){
        var cat_1_ID = $(this).val();
        if(cat_1_ID){
            $.ajax({
                type:'POST',
                url:'ajaxData.php',
                data:'cat_1_id='+cat_1_ID,
                success:function(html){
                    $('#cat_2').html(html);
                    $('#cat_3').html('<option value="">Select category 2 first</option>'); 
					$('#cat_4').html('<option value="">Select category 3 first</option>'); 
                }
            }); 
        }else{
            $('#cat_2').html('<option value="">Select category 1 first</option>');
            $('#cat_3').html('<option value="">Select category 2 first</option>'); 
			$('#cat_4').html('<option value="">Select category 3 first</option>'); 
        }
    });
    
    $('#cat_2').on('change',function(){
        var cat_2_ID = $(this).val();
        if(cat_2_ID){
            $.ajax({
                type:'POST',
                url:'ajaxData.php',
                data:'cat_2_id='+cat_2_ID,
                success:function(html){
                    $('#cat_3').html(html);
					$('#cat_4').html('<option value="">Select category 3 first</option>'); 
                }
            }); 
        }else{
            $('#cat_3').html('<option value="">Select category 2 first</option>'); 
			$('#cat_4').html('<option value="">Select category 3 first</option>'); 
        }
    });
	
	$('#cat_3').on('change',function(){
        var cat_3_ID = $(this).val();
        if(cat_3_ID){
            $.ajax({
                type:'POST',
                url:'ajaxData.php',
                data:'cat_3_id='+cat_3_ID,
                success:function(html){
                    $('#cat_4').html(html);
                }
            }); 
        }else{
            $('#cat_4').html('<option value="">Select category 3 first</option>'); 
        }
    });
});
</script>
</head>
<body>

<table>
<tr>
<td>
<a href="#" onclick="document.getElementById('select-boxes').style.visibility = 'visible'; document.getElementById('apis').style.visibility = 'hidden'; ">New Application Request</a></td><td><a href="#" onclick="document.getElementById('select-boxes').style.visibility = 'hidden'; document.getElementById('apis').style.visibility = 'visible';">Add API Parameters</a></td><td>
<a href="view.php" >View New Applications Requested</a>
</td>
</tr>
</table>
    <p>
	<div id="select-boxes" class="select-boxes" style="visibility: hidden; position: fixed">
	
	<?php
	
    //Include database configuration file
    include('dbconfig.php');
    
    //Get all category 1 data
    $query = $db->query("SELECT * FROM cat_1 ORDER BY cat_1 ASC");
    
    //Count total number of rows
    $rowCount = $query->num_rows;
    ?>
	<form action="addreq.php" method="post" enctype="multipart/form-data">
	<table>
	<tr>
	<td nowrap>Application Title</td><td><input type="text" name="title"></td>
	</tr>
	<tr>
	<td nowrap>Category</td>
	<td>
    <select name="cat_1" id="cat_1">
        <option value="">Select category 1</option>
        <?php
        if($rowCount > 0){
            while($row = $query->fetch_assoc()){ 
                echo '<option value="'.$row['cat_1_id'].'">'.$row['cat_1'].'</option>';
            }
        }else{
            echo '<option value="">Category 1 not available</option>';
        }
        ?>
    </select>
    <br />
    <select name="cat_2" id="cat_2">
        <option value="">Select category 1 first</option>
    </select>
    <br />
    <select name="cat_3" id="cat_3">
        <option value="">Select category 2 first</option>
    </select>
	<br />
	<select name="cat_4" id="cat_4">
        <option value="">Select category 3 first</option>
    </select>
	<br />
	</td>
	</tr>
	<tr>
	<td nowrap>Description</td><td><textarea name="description" style="width: 350px; height: 100px;"></textarea></td>
	</tr>
	<tr>
	<td nowrap>Metadata</td><td><input type="text" name="metadata"></td>
	</tr>
	<tr>
	<td nowrap>Delivery URL</td><td><input type="text" name="delivery_url"></td>
	</tr>
	<tr>
	<td nowrap>Hosted URL</td><td><input type="text" name="hosted_url"></td>
	</tr>
	<tr>
	<td nowrap>Secret</td><td><input type="text" name="secret"></td>
	</tr>
	<tr>
	<td nowrap>Key</td><td><input type="text" name="appkey"></td>
	</tr>
	<tr>
	<td nowrap>Username</td><td><input type="text" name="username"></td>
	</tr>
	<tr>
	<td nowrap>Password</td><td><input type="password" name="password"></td>
	</tr>
	<tr>
	<td nowrap>Date</td><td><input type="date" name="date_added"></td>
	</tr>
	<tr>
	<td nowrap colspan="2" class='dblcol'><input type="Submit" name="Submit"></td>
	</tr>
	</table>
	</form>
    </div>
	
	<div id="apis" class="select-boxes" style="visibility: hidden; position: fixed;">
	<form action="addapi.php" method="post" enctype="multipart/form-data">
	<table>
	<tr>
	<td nowrap>Application Name</td><td><select name="app_id">
	<?php
	$sql = "SELECT * FROM cs_app_req ORDER BY title ASC";
	$result = $db->query($sql);
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
		echo "<option value='".$row['id']."'>".$row['title']."</option>";	
		}
	} else {
		echo "<option value=''>No Existing Application</option>";	
	}
	?>	
	</select>
	</td>
	</tr>
	<tr>
	<td>Parameter Name</td><td><input type="text" name="parameter_name"></td>
	</tr>
	<tr>
	<td>Parameter</td><td><textarea name="parameter" style="width: 350px; height: 100px;"></textarea></td>
	</tr>
	<tr>
	<td>Date</td><td><input type="date" name="date_added"></td>
	</tr>
	<tr>
	<td nowrap colspan="2" class='dblcol'><input type="Submit" name="Submit"></td>
	</tr>
	</table>
	</form>
	</div>
	
</body>
</html>

<?php
	} else {
	?>
	You do not have access to this page
	<?php
	}
