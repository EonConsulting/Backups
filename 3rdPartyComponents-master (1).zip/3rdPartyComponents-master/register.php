<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>Registration Confirmation</title>
    <link href="css/style.css" rel="stylesheet">
	
</head>
<body>

<?php
include 'dbconfig.php';
include 'function.php';

$firstname = mysqli_real_escape_string($db, $_POST['firstname']);
$lastname = mysqli_real_escape_string($db, $_POST['lastname']);
$email = mysqli_real_escape_string($db, $_POST['email']);
$username = mysqli_real_escape_string($db, $_POST['username']);
$password = mysqli_real_escape_string($db, $_POST['password']);
$status = "inactive";

//check if username is unique
$sql = "SELECT * FROM user_details WHERE username='" . $username . "'";
$result = $db->query($sql);
if ($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
		echo "The Username is already taken. Please go back and change the username<br />";
		echo "<a href='registration.php'>Click here</a> to go back";
	}
} else {
	CheckEmail();
}

$db->close();
?>
</body>
</html>