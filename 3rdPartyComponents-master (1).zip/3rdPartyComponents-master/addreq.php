<?php
include 'dbconfig.php';

$title = mysqli_real_escape_string($db, $_POST['title']);
$cat_lvl_1 = mysqli_real_escape_string($db, $_POST['cat_1']);
$cat_lvl_2 = mysqli_real_escape_string($db, $_POST['cat_2']);
$cat_lvl_3 = mysqli_real_escape_string($db, $_POST['cat_3']);
$cat_lvl_4 = mysqli_real_escape_string($db, $_POST['cat_4']);
$description = mysqli_real_escape_string($db, $_POST['description']);
$metadata = mysqli_real_escape_string($db, $_POST['metadata']);
$delivery_url = mysqli_real_escape_string($db, $_POST['delivery_url']);
$hosted_url = mysqli_real_escape_string($db, $_POST['hosted_url']);
$secret = mysqli_real_escape_string($db, $_POST['secret']);
$appkey = mysqli_real_escape_string($db, $_POST['appkey']);
$username = mysqli_real_escape_string($db, $_POST['username']);
$password = mysqli_real_escape_string($db, MD5($_POST['password']));
$date_added = mysqli_real_escape_string($db, $_POST['date_added']);
	
$sql = "SELECT * FROM cs_app_req WHERE title='$title'";
$result = $db->query($sql);
if ($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
	echo "An application with the title $title already exists";	
	}
} else {
	$sql="INSERT INTO cs_app_req(title, cat_lvl_1, cat_lvl_2, cat_lvl_3, cat_lvl_4, description, metadata, delivery_url, hosted_url, secret, appkey, username, password, date_added) VALUES ('$title', '$cat_lvl_1', '$cat_lvl_2', '$cat_lvl_3', '$cat_lvl_4', '$description', '$metadata', '$delivery_url', '$hosted_url', '$secret', '$appkey', '$username', '$password', '$date_added')";
	$result = $db->query($sql);
	echo "<h4>New Application Request added.</h4><br />";
	echo "<a href='auth.php'>Click here</a> to go back";
}
		
