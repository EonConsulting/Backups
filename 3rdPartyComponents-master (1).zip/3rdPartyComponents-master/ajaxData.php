<?php
//Include database configuration file
include('dbConfig.php');

if(isset($_POST["cat_1_id"]) && !empty($_POST["cat_1_id"])){
    //Get all category 2 data
    $query = $db->query("SELECT * FROM cat_2 WHERE cat_1_id = ".$_POST['cat_1_id']." ORDER BY cat_2 ASC");
    
    //Count total number of rows
    $rowCount = $query->num_rows;
    
    //Display category 2 list
    if($rowCount > 0){
        echo '<option value="">Select category 2</option>';
        while($row = $query->fetch_assoc()){ 
            echo '<option value="'.$row['cat_2_id'].'">'.$row['cat_2'].'</option>';
        }
    }else{
        echo '<option value="">Category 2 not available</option>';
    }
}

if(isset($_POST["cat_2_id"]) && !empty($_POST["cat_2_id"])){
    //Get all category 3 data
    $query = $db->query("SELECT * FROM cat_3 WHERE cat_2_id = ".$_POST['cat_2_id']." ORDER BY cat_3 ASC");
    
    //Count total number of rows
    $rowCount = $query->num_rows;
    
    //Display category 3 list
    if($rowCount > 0){
        echo '<option value="">Select category 3</option>';
        while($row = $query->fetch_assoc()){ 
            echo '<option value="'.$row['cat_3_id'].'">'.$row['cat_3'].'</option>';
        }
    }else{
        echo '<option value="">Category 3 not available</option>';
    }
}

if(isset($_POST["cat_3_id"]) && !empty($_POST["cat_3_id"])){
    //Get all category 4 data
    $query = $db->query("SELECT * FROM cat_4 WHERE cat_3_id = ".$_POST['cat_3_id']." ORDER BY cat_4 ASC");
    
    //Count total number of rows
    $rowCount = $query->num_rows;
    
    //Display category 4 list
    if($rowCount > 0){
        echo '<option value="">Select category 4</option>';
        while($row = $query->fetch_assoc()){ 
            echo '<option value="'.$row['cat_4_id'].'">'.$row['cat_4'].'</option>';
        }
    }else{
        echo '<option value="">Category 4 not available</option>';
    }
}
?>