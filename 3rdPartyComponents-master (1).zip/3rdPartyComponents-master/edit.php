<?php
	session_start();
	
	//Include functions
	include 'function.php';
	// check if username session exists
	if(isset($_SESSION['username'])){
		?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Edit - Third Party Application Request</title>
<link href="css/style.css" rel="stylesheet">
<script src="jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    $('#cat_1').on('change',function(){
        var cat_1_ID = $(this).val();
        if(cat_1_ID){
            $.ajax({
                type:'POST',
                url:'ajaxData.php',
                data:'cat_1_id='+cat_1_ID,
                success:function(html){
                    $('#cat_2').html(html);
                    $('#cat_3').html('<option value="">Select category 2 first</option>'); 
					$('#cat_4').html('<option value="">Select category 3 first</option>'); 
                }
            }); 
        }else{
            $('#cat_2').html('<option value="">Select category 1 first</option>');
            $('#cat_3').html('<option value="">Select category 2 first</option>'); 
			$('#cat_4').html('<option value="">Select category 3 first</option>'); 
        }
    });
    
    $('#cat_2').on('change',function(){
        var cat_2_ID = $(this).val();
        if(cat_2_ID){
            $.ajax({
                type:'POST',
                url:'ajaxData.php',
                data:'cat_2_id='+cat_2_ID,
                success:function(html){
                    $('#cat_3').html(html);
					$('#cat_4').html('<option value="">Select category 3 first</option>'); 
                }
            }); 
        }else{
            $('#cat_3').html('<option value="">Select category 2 first</option>'); 
			$('#cat_4').html('<option value="">Select category 3 first</option>'); 
        }
    });
	
	$('#cat_3').on('change',function(){
        var cat_3_ID = $(this).val();
        if(cat_3_ID){
            $.ajax({
                type:'POST',
                url:'ajaxData.php',
                data:'cat_3_id='+cat_3_ID,
                success:function(html){
                    $('#cat_4').html(html);
                }
            }); 
        }else{
            $('#cat_4').html('<option value="">Select category 3 first</option>'); 
        }
    });
});
</script>
</head>
<body>
    <p>
	<a href='auth.php'><button>Home</button></a><p>
	<div id="select-boxes" class="select-boxes" style="visibility: visible; position: fixed">
	
	<?php
	
	//Include database configuration file
    include('dbconfig.php');
    
	//get details of the existing application
	global $app_id;
	$app_id = $_GET['id'];
	$sql="SELECT * FROM cs_app_req WHERE id='$app_id'";
	$result = $db->query($sql);
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			// assign known details and get the category names for each category level
			$title = $row['title'];
			$description = $row['description'];
			$metadata = $row['metadata'];
			$delivery_url = $row['delivery_url'];
			$hosted_url = $row['hosted_url'];
			$secret = $row['secret'];
			$appkey = $row['appkey'];
			$username = $row['username'];
			$password = $row['password'];
			$date_added = $row['date_added'];
			$cat_1 = $row['cat_lvl_1'];
			$cat_2 = $row['cat_lvl_2'];
			$cat_3 = $row['cat_lvl_3'];
			$cat_4 = $row['cat_lvl_4'];
			
			//get category names for each category level
			$sql = "SELECT * FROM cat_1 WHERE cat_1_id='$cat_1'";
			$result = mysqli_query($db,$sql);
			$row=mysqli_fetch_assoc($result);
			$cat_1 = $row['cat_1'];
			
			$sql = "SELECT * FROM cat_2 WHERE cat_2_id='$cat_2'";
			$result = mysqli_query($db,$sql);
			$row=mysqli_fetch_assoc($result);
			$cat_2 = $row['cat_2'];
			
			$sql = "SELECT * FROM cat_3 WHERE cat_3_id='$cat_3'";
			$result = mysqli_query($db,$sql);
			$row=mysqli_fetch_assoc($result);
			$cat_3 = $row['cat_3'];
			
			$sql = "SELECT * FROM cat_4 WHERE cat_4_id='$cat_4'";
			$result = mysqli_query($db,$sql);
			$row=mysqli_fetch_assoc($result);
			$cat_4 = $row['cat_4'];
		}
	}
	
    //Get all category 1 data
    $query = $db->query("SELECT * FROM cat_1 ORDER BY cat_1 ASC");
    
    //Count total number of rows
    $rowCount = $query->num_rows;
    ?>
	<form action="editreq.php" method="post" enctype="multipart/form-data">
	<table>
	<tr>
	<td nowrap>Application Title</td><td><input type="text" name="id" value="<?php echo $app_id; ?>" hidden><?php echo $title; ?></td>
	</tr>
	<tr>
	<td nowrap>Category</td>
	<td>
    <select name="cat_1" id="cat_1">
        <option value="">Select category 1</option>
        <?php
        if($rowCount > 0){
            while($row = $query->fetch_assoc()){ 
                echo '<option value="'.$row['cat_1_id'].'">'.$row['cat_1'].'</option>';
            }
        }else{
            echo '<option value="">Category 1 not available</option>';
        }
        ?>
    </select>
    <br />
    <select name="cat_2" id="cat_2">
        <option value="">Select category 1 first</option>
    </select>
    <br />
    <select name="cat_3" id="cat_3">
        <option value="">Select category 2 first</option>
    </select>
	<br />
	<select name="cat_4" id="cat_4">
        <option value="">Select category 3 first</option>
    </select>
	<br />
	</td>
	</tr>
	<tr>
	<td nowrap>Description</td><td><textarea name="description" style="width: 350px; height: 100px;"><?php echo $description; ?></textarea></td>
	</tr>
	<tr>
	<td nowrap>Metadata</td><td><input type="text" name="metadata" value="<?php echo $metadata; ?>"></td>
	</tr>
	<tr>
	<td nowrap>Delivery URL</td><td><input type="text" name="delivery_url" value="<?php echo $delivery_url; ?>"></td>
	</tr>
	<tr>
	<td nowrap>Hosted URL</td><td><input type="text" name="hosted_url" value="<?php echo $hosted_url; ?>"></td>
	</tr>
	<tr>
	<td nowrap>Secret</td><td><input type="text" name="secret" value="<?php echo $secret; ?>"></td>
	</tr>
	<tr>
	<td nowrap>Key</td><td><input type="text" name="appkey" value="<?php echo $appkey; ?>"></td>
	</tr>
	<tr>
	<td nowrap>Username</td><td><input type="text" name="username" value="<?php echo $username; ?>"></td>
	</tr>
	<tr>
	<td nowrap>Password</td><td><input type="password" name="password" value="<?php echo $password; ?>"></td>
	</tr>
	<tr>
	<td nowrap colspan="2" class='dblcol'><input type="Submit" name="Submit" value="Update"></td>
	</tr>
	</table>
	</form>
    </div>
	
</body>
</html>

<?php
	} else {
	?>
	You do not have access to this page
	<?php
	}