<?php

//check if email is unique
function CheckEmail(){
	include 'dbconfig.php';
	
	$email_exp = '/^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/';
	if(!preg_match($email_exp,$GLOBALS['email'])) {
		echo $error_message .= 'The Email Address you entered does not appear to be valid.<br />';
		echo "<a href='registration.php'>Click here</a> to go back";
	} else {
		$sql = "SELECT * FROM user_details WHERE email='" . $GLOBALS['email'] . "'";
		$result = $db->query($sql);
		if ($result->num_rows > 0) {
			while($row = $result->fetch_assoc()) {
				echo "The email address is already registered. ";
			}
		} else {
			CheckNewPassword();
		}
	}
}

//check password match and not blank
function CheckNewPassword(){
	if ($_POST['password'] == ""){
		echo "<h4>Your password cannot be blank</h4>";
	} elseif ($_POST['password'] != $_POST['confirmpass']){
		echo "<h4>Your password and confirm password do not match.<br>Please fix the error and try again.</h4><br />";
		echo "<a href='registration.php'>Click here</a> to go back";
	} else {
		CreateUser();
	}
}

//create user account
function CreateUser(){
	include 'dbconfig.php';
	$firstname = mysqli_real_escape_string($db, $_POST['firstname']);
	$lastname = mysqli_real_escape_string($db, $_POST['lastname']);
	$email = mysqli_real_escape_string($db, $_POST['email']);
	$username = mysqli_real_escape_string($db, $_POST['username']);
	$password = mysqli_real_escape_string($db, $_POST['password']);

	$sql="INSERT INTO user_details(firstname, lastname, email, username, password) VALUES ('$firstname', '$lastname', '$email', '$username', MD5('$password'))";
	$result = $db->query($sql);
	echo "<h4>Thank you for registering.</h4><br />";
	echo "<a href='index.php'>Click here</a> to go to the login page";
	//SendEmail();
}

// check password against username
function CheckPassword(){
	include 'dbconfig.php';
	$sql = "SELECT * FROM user_details WHERE username='" . $_SESSION['username'] . "'";
	$result = $db->query($sql);
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			if (MD5($_SESSION['password']) == $row['password']){
				return;
			} else {
				echo "<h4>Your password is not correct.<br>Please fix the error and try again.</h4>";
				exit();
			}
		}
	} else {
		echo "<h4>The user does not exist.<br></h4>";
		exit();
	}
}
