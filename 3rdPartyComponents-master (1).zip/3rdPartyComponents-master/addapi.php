<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>Add API - Third Party Application Request</title>
    <link href="css/style.css" rel="stylesheet">
	
</head>
<body>
<?php
include 'dbconfig.php';

$app_id = mysqli_real_escape_string($db, $_POST['app_id']);
$parameter_name = mysqli_real_escape_string($db, $_POST['parameter_name']);
$parameter = mysqli_real_escape_string($db, $_POST['parameter']);
$date_added = mysqli_real_escape_string($db, $_POST['date_added']);
	
$sql="INSERT INTO cs_app_api(app_id, parameter_name, parameter, date_added) VALUES ('$app_id', '$parameter_name', '$parameter', '$date_added')";
	$result = $db->query($sql);
	echo "<h4>New API added.</h4><br />";
	echo "<a href='auth.php'>Click here</a> to go back";

		
