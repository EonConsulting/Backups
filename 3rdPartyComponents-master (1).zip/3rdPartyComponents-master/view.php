<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>View - Third Party Application Request</title>
    <link href="css/style.css" rel="stylesheet">
	
</head>
<body>
<?php
session_start();
include 'dbconfig.php';
if (isset($_SESSION['username'])){
	echo "<h3>Applications requested: </h3><p>
	<a href='auth.php'><button>Home</button></a>";
	echo "<table border='1'>
			<tr>
				<td><b>Application Title</b></td><td><b>Details</b></td><td><b>Date Added</b></td>
			</tr>
	";
	// get a list of applications requested
	$sql="SELECT * FROM cs_app_req ORDER BY title ASC";
	$result = $db->query($sql);
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			echo "<tr><td>".$row['title']."</td><td><a href='viewdetails.php?id=".$row['id']."'>View</a></td><td>".$row['date_added']."</td></tr>";
		}
	} else {
		echo "No records found";
	}
	echo "</table>";
	
		
} else {
	echo "You are not allowed to view this page";
}