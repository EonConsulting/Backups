-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 02, 2016 at 01:29 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `3rd_party`
--
CREATE DATABASE IF NOT EXISTS `3rd_party` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `3rd_party`;

-- --------------------------------------------------------

--
-- Table structure for table `cat_1`
--

CREATE TABLE `cat_1` (
  `cat_1_id` int(10) UNSIGNED NOT NULL,
  `cat_1` varchar(255) DEFAULT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cat_1`
--

INSERT INTO `cat_1` (`cat_1_id`, `cat_1`, `reg_date`) VALUES
(1, 'Material', '2016-11-23 13:17:24'),
(2, 'Functionality', '2016-11-23 13:17:24'),
(3, 'Geometry', '2016-11-23 13:17:24'),
(4, 'User', '2016-11-23 13:17:24'),
(5, 'Synchronization', '2016-11-23 13:17:24'),
(6, 'Purpose', '2016-11-23 13:17:24');

-- --------------------------------------------------------

--
-- Table structure for table `cat_2`
--

CREATE TABLE `cat_2` (
  `cat_2_id` int(10) UNSIGNED NOT NULL,
  `cat_2` varchar(255) DEFAULT NULL,
  `cat_1_id` int(10) DEFAULT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cat_2`
--

INSERT INTO `cat_2` (`cat_2_id`, `cat_2`, `cat_1_id`, `reg_date`) VALUES
(1, 'Application Type', 1, '2016-11-23 13:22:27'),
(2, 'Collaboration Type', 1, '2016-11-23 13:22:27'),
(3, 'License Type', 1, '2016-11-23 13:22:27'),
(4, 'Discipline Type', 1, '2016-11-23 13:22:27'),
(5, 'Content Type', 1, '2016-11-23 13:22:27'),
(6, 'Rating Type', 1, '2016-11-23 13:22:27'),
(7, 'Revision Type', 1, '2016-11-23 13:22:27'),
(8, 'Localisation Type', 1, '2016-11-23 13:22:27'),
(9, 'Qualification Type', 1, '2016-11-23 13:22:27'),
(10, 'Pedagogical Type', 2, '2016-11-23 13:25:06'),
(11, 'Application Type', 2, '2016-11-23 13:25:06'),
(12, 'Functional Type', 2, '2016-11-23 13:25:06'),
(13, 'System Use Type', 2, '2016-11-23 13:25:06'),
(14, 'Distribution Type', 3, '2016-11-23 13:30:04'),
(15, 'Location Type', 3, '2016-11-23 13:30:04'),
(16, 'Interest Type', 3, '2016-11-23 13:30:04'),
(17, 'Role Type', 4, '2016-11-23 13:30:04'),
(18, 'Institution Type', 4, '2016-11-23 13:30:04'),
(19, 'Enrollment Type', 4, '2016-11-23 13:34:05'),
(20, 'Status Type', 4, '2016-11-23 13:30:04'),
(21, 'Study Cycle Type', 5, '2016-11-23 13:30:04'),
(22, 'Student Cycle Type', 5, '2016-11-23 13:30:04'),
(23, 'TermCycleType', 5, '2016-11-23 13:30:04'),
(24, 'Study Type', 6, '2016-11-23 13:30:04'),
(25, 'Goal Type', 6, '2016-11-23 13:30:04');

-- --------------------------------------------------------

--
-- Table structure for table `cat_3`
--

CREATE TABLE `cat_3` (
  `cat_3_id` int(10) UNSIGNED NOT NULL,
  `cat_3` varchar(255) DEFAULT NULL,
  `cat_2_id` int(10) DEFAULT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cat_3`
--

INSERT INTO `cat_3` (`cat_3_id`, `cat_3`, `cat_2_id`, `reg_date`) VALUES
(1, 'Self-Study', 1, '2016-11-23 13:53:22'),
(2, 'Course based', 1, '2016-11-23 13:53:22'),
(3, 'Student-to-student', 2, '2016-11-23 13:53:22'),
(4, 'Student-to-lecturer', 2, '2016-11-23 13:53:22'),
(5, 'Student-to-group', 2, '2016-11-23 13:53:22'),
(6, 'OSI approved Open Source', 3, '2016-11-23 13:53:22'),
(7, 'Public Domain', 3, '2016-11-23 13:53:22'),
(8, 'Creative Commons Attribution', 3, '2016-11-23 13:53:22'),
(9, 'Commercial', 3, '2016-11-23 13:53:22'),
(10, 'Arts', 4, '2016-11-23 13:53:22'),
(11, 'Humanities', 4, '2016-11-23 13:53:22'),
(12, 'Social Sciences', 4, '2016-11-23 13:53:22'),
(13, 'Sciences', 4, '2016-11-23 13:53:22'),
(14, 'Technology', 4, '2016-11-23 13:53:22'),
(15, 'Learning Content', 5, '2016-11-23 13:53:22'),
(16, 'Lecturers voice', 5, '2016-11-23 13:53:22'),
(17, 'Assessments', 5, '2016-11-23 13:53:22'),
(18, 'Multimedia', 5, '2016-11-24 04:25:17'),
(19, 'Textbooks', 5, '2016-11-24 04:25:29'),
(20, 'Web 2.0', 5, '2016-11-23 13:53:22'),
(21, 'Popularity', 6, '2016-11-23 13:53:22'),
(22, 'Star', 6, '2016-11-23 13:53:22'),
(23, 'Planning', 7, '2016-11-23 13:53:22'),
(24, 'Pre-Alpha', 7, '2016-11-23 13:53:22'),
(25, 'Alpha', 7, '2016-11-23 13:53:22'),
(26, 'Beta', 7, '2016-11-23 13:53:22'),
(27, 'Production / Stable', 7, '2016-11-23 13:53:22'),
(28, 'Mature', 7, '2016-11-23 13:53:22'),
(29, 'Inactive', 7, '2016-11-23 13:53:22'),
(30, 'English', 8, '2016-11-23 13:53:22'),
(31, 'isiZulu', 8, '2016-11-23 13:53:22'),
(32, 'isiXhosa', 8, '2016-11-23 13:53:22'),
(33, 'Afrikaans', 8, '2016-11-23 13:53:22'),
(34, '…', 8, '2016-11-23 13:53:22'),
(35, 'Certificate', 9, '2016-11-23 13:53:22'),
(36, 'Diploma', 9, '2016-11-23 13:53:22'),
(37, 'Degree', 9, '2016-11-23 13:53:22'),
(38, 'Honours Degree', 9, '2016-11-23 13:53:22'),
(39, 'Masters Degree', 9, '2016-11-23 13:53:22'),
(40, 'Doctoral Degree', 9, '2016-11-23 13:53:22'),
(41, 'Outcome based', 10, '2016-11-23 13:53:22'),
(42, 'Schedule Based', 10, '2016-11-23 13:53:22'),
(43, 'Content Based', 10, '2016-11-23 13:53:22'),
(44, 'Online', 11, '2016-11-23 13:53:22'),
(45, 'Offline', 11, '2016-11-23 13:53:22'),
(46, 'Analytics', 12, '2016-11-23 13:53:22'),
(47, 'Study aid (help)', 12, '2016-11-23 13:53:22'),
(48, 'Assessment', 12, '2016-11-23 13:53:22'),
(49, 'Content', 12, '2016-11-23 13:53:22'),
(50, 'Media', 12, '2016-11-23 13:53:22'),
(51, 'Dashboard', 12, '2016-11-23 13:53:22'),
(52, 'Front end use', 13, '2016-11-23 13:53:22'),
(53, 'Back end use', 13, '2016-11-23 13:53:22'),
(54, 'On campus', 14, '2016-11-23 13:53:22'),
(55, 'Correspondence', 14, '2016-11-23 13:53:22'),
(56, 'Online', 14, '2016-11-23 13:53:22'),
(57, 'International students', 15, '2016-11-23 13:53:22'),
(58, 'RSA students', 15, '2016-11-23 13:53:22'),
(59, 'Location bound students', 15, '2016-11-23 13:53:22'),
(60, 'Course', 16, '2016-11-23 13:53:22'),
(61, 'Module', 16, '2016-11-23 13:53:22'),
(62, 'Subject', 16, '2016-11-23 13:53:22'),
(63, 'Topic', 16, '2016-11-23 13:53:22'),
(64, 'Idea', 16, '2016-11-23 13:53:22'),
(65, 'Student', 17, '2016-11-23 13:53:22'),
(66, 'Lecturer', 17, '2016-11-23 13:53:22'),
(67, 'Tutor', 17, '2016-11-23 13:53:22'),
(68, 'Administrator', 17, '2016-11-23 13:53:22'),
(69, 'Proctor', 17, '2016-11-23 13:53:22'),
(70, 'Facilitator', 17, '2016-11-23 13:53:22'),
(71, 'Assistant', 17, '2016-11-23 13:53:22'),
(72, 'Editor', 17, '2016-11-23 13:53:22'),
(73, 'Faculty', 18, '2016-11-23 13:53:22'),
(74, 'School', 18, '2016-11-23 13:53:22'),
(75, 'Department', 18, '2016-11-23 13:53:22'),
(76, 'College', 18, '2016-11-23 13:53:22'),
(77, 'Academy', 18, '2016-11-23 13:53:22'),
(78, 'Institute', 18, '2016-11-23 13:53:22'),
(79, 'Full-time', 19, '2016-11-23 13:53:22'),
(80, 'Part-time', 19, '2016-11-23 13:53:22'),
(81, 'Potential student', 20, '2016-11-23 13:53:22'),
(82, 'Registered student', 20, '2016-11-23 13:53:22'),
(83, 'Alumni', 20, '2016-11-23 13:53:22'),
(84, 'Application', 21, '2016-11-23 13:53:22'),
(85, 'Admittance', 21, '2016-11-23 13:53:22'),
(86, 'Registration', 21, '2016-11-23 13:53:22'),
(87, 'Study', 21, '2016-11-23 13:53:22'),
(88, 'Examination', 21, '2016-11-23 13:53:22'),
(89, 'Graduation', 21, '2016-11-23 13:53:22'),
(90, 'Undergraduate', 22, '2016-11-23 13:53:22'),
(91, 'Graduate', 22, '2016-11-23 13:53:22'),
(92, 'Postgraduate', 22, '2016-11-23 13:53:22'),
(93, '1st Term', 23, '2016-11-23 13:53:22'),
(94, '2nd Term', 23, '2016-11-23 13:53:22'),
(95, '3rd Term', 23, '2016-11-23 13:53:22'),
(96, '4th Term', 23, '2016-11-23 13:53:22'),
(97, 'Revision', 24, '2016-11-23 13:53:22'),
(98, '1st registration', 24, '2016-11-23 13:53:22'),
(99, 'Repeat Student', 24, '2016-11-23 13:53:22'),
(100, 'Professional Qualification', 25, '2016-11-23 13:53:22'),
(101, 'Certification', 25, '2016-11-23 13:53:22'),
(102, 'Continued Education', 25, '2016-11-23 13:53:22'),
(103, 'Research', 25, '2016-11-23 13:53:22'),
(104, 'Professional Registration', 25, '2016-11-23 13:53:22');

-- --------------------------------------------------------

--
-- Table structure for table `cat_4`
--

CREATE TABLE `cat_4` (
  `cat_4_id` int(10) UNSIGNED NOT NULL,
  `cat_4` varchar(255) DEFAULT NULL,
  `cat_3_id` int(10) DEFAULT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cat_4`
--

INSERT INTO `cat_4` (`cat_4_id`, `cat_4`, `cat_3_id`, `reg_date`) VALUES
(1, 'Performing Arts', 10, '2016-11-24 04:45:32'),
(2, 'Visual arts', 10, '2016-11-24 04:45:32'),
(3, 'Geography', 11, '2016-11-24 04:45:32'),
(4, 'History', 11, '2016-11-24 04:45:32'),
(5, 'Language and Literature', 11, '2016-11-24 04:45:32'),
(6, 'Philosophy', 11, '2016-11-24 04:45:32'),
(7, 'Economics', 12, '2016-11-24 04:45:32'),
(8, 'Law', 12, '2016-11-24 04:45:32'),
(9, 'Political Science', 12, '2016-11-24 04:45:32'),
(10, 'Psychology', 12, '2016-11-24 04:45:32'),
(11, 'Sociology', 12, '2016-11-24 04:45:32'),
(12, 'Biology', 13, '2016-11-24 04:45:32'),
(13, 'Chemistry', 13, '2016-11-24 04:45:32'),
(14, 'Earth and Space Sciences', 13, '2016-11-24 04:45:32'),
(15, 'Mathematics', 13, '2016-11-24 04:45:32'),
(16, 'Physics', 13, '2016-11-24 04:45:32'),
(17, 'Agronomy', 14, '2016-11-24 04:45:32'),
(18, 'Computer Science', 14, '2016-11-24 04:45:32'),
(19, 'Engineering', 14, '2016-11-24 04:45:32'),
(20, 'Medicine', 14, '2016-11-24 04:45:32'),
(21, 'Always', 21, '2016-11-24 04:45:32'),
(22, 'Often', 21, '2016-11-24 04:45:32'),
(23, 'Sometimes', 21, '2016-11-24 04:45:33'),
(24, 'Rarely', 21, '2016-11-24 04:45:33'),
(25, 'Never', 21, '2016-11-24 04:45:33'),
(26, '*', 22, '2016-11-24 04:45:33'),
(27, '**', 22, '2016-11-24 04:45:33'),
(28, '***', 22, '2016-11-24 04:45:33'),
(29, '****', 22, '2016-11-24 04:45:33'),
(30, '*****', 22, '2016-11-24 04:45:33');

-- --------------------------------------------------------

--
-- Table structure for table `cs_app_api`
--

CREATE TABLE `cs_app_api` (
  `id` int(6) UNSIGNED NOT NULL,
  `app_id` varchar(255) NOT NULL,
  `parameter_name` varchar(255) DEFAULT NULL,
  `parameter` text,
  `date_added` date DEFAULT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cs_app_api`
--

INSERT INTO `cs_app_api` (`id`, `app_id`, `parameter_name`, `parameter`, `date_added`, `reg_date`) VALUES
(1, '1', '6', '6', '2016-11-24', '2016-11-25 07:47:45'),
(2, '1', '6', '6', '2016-11-24', '2016-11-25 07:47:45'),
(3, '2', 'Param Name', 'Parameter details supplied here for dashboard', '2016-11-24', '2016-11-24 08:50:44'),
(4, '3', 'GH Parameter Name', 'Parameter details for the GreenHouse', '2016-11-24', '2016-11-24 09:18:57'),
(5, '3', 'GH Parameter 2 Name', 'Greenhouse Parameter details for API 2', '2016-11-24', '2016-11-24 09:56:21'),
(6, '4', 'Strudent ID', 'Details about student ID', '2016-11-24', '2016-11-24 10:34:47'),
(7, '1', '6', '6', '2016-11-24', '2016-11-25 07:47:45');

-- --------------------------------------------------------

--
-- Table structure for table `cs_app_req`
--

CREATE TABLE `cs_app_req` (
  `id` int(6) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `cat_lvl_1` varchar(255) NOT NULL,
  `cat_lvl_2` varchar(255) DEFAULT NULL,
  `cat_lvl_3` varchar(255) DEFAULT NULL,
  `cat_lvl_4` varchar(255) DEFAULT NULL,
  `description` text,
  `metadata` varchar(255) DEFAULT NULL,
  `delivery_url` text,
  `hosted_url` text,
  `secret` varchar(255) DEFAULT NULL,
  `appkey` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `date_added` date DEFAULT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cs_app_req`
--

INSERT INTO `cs_app_req` (`id`, `title`, `cat_lvl_1`, `cat_lvl_2`, `cat_lvl_3`, `cat_lvl_4`, `description`, `metadata`, `delivery_url`, `hosted_url`, `secret`, `appkey`, `username`, `password`, `date_added`, `reg_date`) VALUES
(1, 'Whiteboard', '1', '4', '13', '16', 'An online whiteboard to share information', 'n/a', 'https://awwapp.com/', 'https://awwapp.com/', 'secret', 'key', 'admin', '202cb962ac59075b964b07152d234b70', '2016-11-24', '2016-11-24 11:58:10'),
(2, 'Dashboard', '1', '1', '1', '', 'An online dashboard for users to make notes', 'dashboard', 'www.dashboard.com', 'www.dashboard.com', 'secret', 'someotherkey', 'johnny', '202cb962ac59075b964b07152d234b70', '2016-11-24', '2016-11-25 04:43:10'),
(3, 'Greenhouse', '2', '11', '45', '', 'An online greenhouse for biology simulations', 'greenhouse', 'www.greenhouse.com', 'www.greenhouse.com', 'secret', 'Greener', 'ben', '202cb962ac59075b964b07152d234b70', '2016-11-24', '2016-11-25 07:53:12'),
(4, 'Student Enrolment', '4', '19', '79', '', 'Students will enrole', 'enrolley', 'www.enrole.co.za', 'www.enrole.co.za', 'secret', 'key', '', 'd41d8cd98f00b204e9800998ecf8427e', '2016-11-24', '2016-11-24 10:34:09');

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `id` int(6) UNSIGNED NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `email` varchar(150) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`id`, `username`, `password`, `firstname`, `lastname`, `email`, `reg_date`) VALUES
(1, 'mshariff', 'e8f0220442452a99277b9ca394de3236', 'Mohamed', 'Shariff', 'mohamed@ttro.com', '2016-11-23 10:15:12'),
(2, 'admin', 'e8f0220442452a99277b9ca394de3236', 'Mohamed', 'Shariff', 'mshariff@mweb.co.za', '2016-11-24 07:34:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cat_1`
--
ALTER TABLE `cat_1`
  ADD PRIMARY KEY (`cat_1_id`);

--
-- Indexes for table `cat_2`
--
ALTER TABLE `cat_2`
  ADD PRIMARY KEY (`cat_2_id`);

--
-- Indexes for table `cat_3`
--
ALTER TABLE `cat_3`
  ADD PRIMARY KEY (`cat_3_id`);

--
-- Indexes for table `cat_4`
--
ALTER TABLE `cat_4`
  ADD PRIMARY KEY (`cat_4_id`);

--
-- Indexes for table `cs_app_api`
--
ALTER TABLE `cs_app_api`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cs_app_req`
--
ALTER TABLE `cs_app_req`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cat_1`
--
ALTER TABLE `cat_1`
  MODIFY `cat_1_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `cat_2`
--
ALTER TABLE `cat_2`
  MODIFY `cat_2_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `cat_3`
--
ALTER TABLE `cat_3`
  MODIFY `cat_3_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;
--
-- AUTO_INCREMENT for table `cat_4`
--
ALTER TABLE `cat_4`
  MODIFY `cat_4_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `cs_app_api`
--
ALTER TABLE `cs_app_api`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `cs_app_req`
--
ALTER TABLE `cs_app_req`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `user_details`
--
ALTER TABLE `user_details`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
