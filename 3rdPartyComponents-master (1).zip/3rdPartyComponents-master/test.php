<!DOCTYPE html>
<html>
<body>

<?php  

$a = array('id'=>1,'param_name'=>'sdfsdf','parameter'=>'sdfdf');
$b = array(2,'sdfsdf','sdfdf');
$c = array(7,'sdfsdf','sdfdf');

$colors = array($a, $b, $c); 

foreach ($colors as $value) {
  var_dump($value);
}
?>  

</body>
</html