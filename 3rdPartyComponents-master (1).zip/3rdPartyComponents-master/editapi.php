<?php
session_start();

//Include functions
include 'function.php';
// check if username session exists
if(isset($_SESSION['username'])){
	?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Edit API - Third Party Application Request</title>
<link href="css/style.css" rel="stylesheet">

</head>
<body>
<p>
<a href='auth.php'><button>Home</button></a><p>

<?php
include "dbconfig.php";
$app_id = $_GET['id'];
$count ='';
?>

<form action="updateapi.php" method="post" enctype="multipart/form-data">
<table>
<tr>
<td align="center"><strong>Id</strong></td>
<td align="center"><strong>Parameter Name</strong></td>
<td align="center"><strong>Parameter</strong></td>
</tr>

<?php
// Count table rows

$sql="SELECT * FROM cs_app_api WHERE app_id='$app_id'";
$result = $db->query($sql);
$records = array();
if ($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
		echo "<tr>
		<td align='center'><input name='id[]' type='text' id='id' value='".$row['id']."' hidden>".$row['id']."</td>
		<td align='center'><input name='parameter_name[]' type='text' id='parameter_name' value='".$row['parameter_name']."'></td>
		<td align='center'><input name='parameter[]' type='text' id='parameter' value='".$row['parameter']."'></td>
		</tr>";
		$count = $count + 1;
	}
echo "<input name='count' type='text' value='$count' hidden>";
	
}
?>

<tr>
<td colspan="3" align="center"><input type="submit" name="Submit" value="Submit" onClick"Blah();"></td>
</tr>
</table>
</form>
<script type="text/javascript">
function UpdateAPI(){
	<?php
	for($i=0;$i<$count;$i++){
		$sql1="UPDATE cs_app_api SET parameter_name='".$_POST['parameter_name'][$i]."', parameter='". $_POST['parameter'][$i]."' WHERE id='".$_POST['id'][$i]."'";
		$result1 = $db->query($sql1);
	}
?>
redirect();
}

function redirect(){
alert('Success');
}
</script>

<?php

// Check if button name "Submit" is active, do this 
?>


<?php
} else {
	?>
	You do not have access to this page
	<?php
	}