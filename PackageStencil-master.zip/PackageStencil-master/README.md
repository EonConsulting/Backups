# PHP Package Stencil

All the documentation can be found here: [PHP Package Stencil Wiki](https://github.com/EonConsulting/PackageStencil/wiki)