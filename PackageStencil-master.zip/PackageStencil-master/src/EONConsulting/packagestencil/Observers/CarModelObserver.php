<?php
/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/22/2016
 * Time: 3:33 PM
 */

namespace EONConsulting\PackageStencil\Observers;


class CarModelObserver implements \SplObserver {

    public function update(\SplSubject $event) {
        echo 'The car model is: ' . $event->model;
    }

}