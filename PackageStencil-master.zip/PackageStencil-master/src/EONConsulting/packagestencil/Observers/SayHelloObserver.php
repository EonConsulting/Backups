<?php

namespace EONConsulting\PackageStencil\Observers;

/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/22/2016
 * Time: 3:17 PM
 */
class SayHelloObserver implements \SplObserver {

    public function update(\SplSubject $event) {
        echo 'Hello world from SayHelloObserver: from, ' . $event->get_name();
    }

}