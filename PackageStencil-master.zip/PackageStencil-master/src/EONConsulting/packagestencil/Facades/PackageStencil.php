<?php

namespace EONConsulting\PackageStencil\Facades;

use \Illuminate\Support\Facades\Facade;

/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/22/2016
 * Time: 11:59 AM
 */
class PackageStencil extends Facade {

    public static function getFacadeAccessor() {
        return 'packagestencil';
    }

}