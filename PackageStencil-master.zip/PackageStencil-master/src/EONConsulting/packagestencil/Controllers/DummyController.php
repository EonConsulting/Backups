<?php
namespace EONConsulting\PackageStencil\Controllers;
//use EONConsulting\PackageStencil\Factories\GUI\GUIEnum;
//use EONConsulting\PackageStencil\Factories\GUI\GUIFactory;
//use EONConsulting\PackageStencil\Factories\Text\TextEnum;
//use EONConsulting\PackageStencil\Factories\Text\TextFactory;
//use EONConsulting\PackageStencil\Factories\AdapterFactory;

/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/22/2016
 * Time: 11:30 AM
 */
class DummyController
{
    public function sayHello() {

       /* $factory = new TextFactory(new AdapterFactory);

        $text = $factory->make(TextEnum::JSON);

        return $text->output(['Hello text']);
       */

//       $factory = new GUIFactory(new AdapterFactory);
//       $gui = $factory->make(GUIEnum::FORM);
//       return $gui->render(["hello_message" => "Hello GUI"]);

        return packagestencil()->render('form', ["hello_message" => "Hello GUI"]);
    }
}