<?php

namespace EONConsulting\PackageStencil\Factories\GUI;

use EONConsulting\PackageStencil\Factories\AdapterFactory;
use EONConsulting\PackageStencil\Factories\Factory;

/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/23/2016
 * Time: 11:24 AM
 */
class GUIFactory implements Factory {

    protected $adapter;

    /**
     * GUIFactory constructor.
     * @param AdapterFactory $adapter
     */
    public function __construct(AdapterFactory $adapter) {
        $this->adapter = $adapter;
    }

    /**
     * Return a new Text object with the correct adapter
     * @param $config
     * @return GUI
     */
    public function make($config) {
        return new GUI($this->adapter->make($config));
    }

}