<?php

namespace EONConsulting\PackageStencil\Factories\Text;

/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/23/2016
 * Time: 8:55 AM
 */
class TextEnum {

    const JSON = 'JSON';
    const XML = 'XML';
    const CSV = 'CSV';

    /**
     * carry on the sequence if you need to add more TEXT TYPES here...
     */

    // const NEW_TYPE = 'NEW_TYPE';

}