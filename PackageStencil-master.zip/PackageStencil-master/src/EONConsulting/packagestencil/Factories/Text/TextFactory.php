<?php

namespace EONConsulting\PackageStencil\Factories\Text;
use EONConsulting\PackageStencil\Factories\AdapterFactory;
use EONConsulting\PackageStencil\Factories\Factory;

/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/23/2016
 * Time: 8:46 AM
 */
class TextFactory implements Factory {

    protected $adapter;

    /**
     * TextFactory constructor.
     * @param AdapterFactory $adapter
     */
    public function __construct(AdapterFactory $adapter) {
        $this->adapter = $adapter;
    }

    /**
     * Return a new Text object with the correct adapter
     * @param $config
     * @return Text
     */
    public function make($config) {
        return new Text($this->adapter->make($config));
    }

}