<?php

namespace EONConsulting\PackageStencil\Factories\Text;

/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/23/2016
 * Time: 8:51 AM
 */
class Text {

    protected $adapter;

    /**
     * Text constructor.
     * @param $adapter
     */
    public function __construct($adapter) {

        // get the set adapter for the different type of format needed
        $this->adapter = $adapter;
    }

    /**
     * Output the data with the correct format
     * @param $data
     * @return mixed
     */
    public function output($data) {
        return $this->adapter->output($data);
    }

}