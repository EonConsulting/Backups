<?php
namespace EONConsulting\PackageStencil\Factories\Text;

/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/23/2016
 * Time: 9:10 AM
 */
interface TextAdapterInterface {

    public function output($data);

}