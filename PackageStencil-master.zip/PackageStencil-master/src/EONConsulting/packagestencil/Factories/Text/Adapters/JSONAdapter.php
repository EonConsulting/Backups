<?php

namespace EONConsulting\PackageStencil\Factories\Text;

/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/23/2016
 * Time: 8:47 AM
 */
class JSONAdapter implements TextAdapterInterface {

    /**
     * Output the data in JSON
     * @param $data
     * @return string
     */
    public function output($data) {
        return json_encode($data);
    }

}