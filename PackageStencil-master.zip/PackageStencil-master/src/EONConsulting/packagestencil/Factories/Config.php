<?php

namespace EONConsulting\PackageStencil\Factories;

/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/23/2016
 * Time: 8:44 AM
 */
class Config {

    /**
     * The DEFAULT config.
     * @var array
     */
    protected $data = [
        'text' => [
            'default' => 'csv'
        ],
        'gui' => [
            'default' => 'list'
        ]
    ];

    /**
     * Get the config value for a specific value given.
     * @param $keys
     * @return array|mixed
     */
    public function get($keys) {
        $data = $this->data;
        $keys = explode('.', $keys);

        foreach ($keys as $key) {
            if (array_key_exists($key, $data)) {
                $data = $data[$key];
                continue;
            }
        }

        return $data;
    }

}