<?php

namespace EONConsulting\PackageStencil\Factories\WebServices;

/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/23/2016
 * Time: 11:56 AM
 */
interface WebServiceAdapterInterface {

    public function output($data);

}