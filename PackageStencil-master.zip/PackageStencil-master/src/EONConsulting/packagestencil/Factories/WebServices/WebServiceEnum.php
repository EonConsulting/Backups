<?php
namespace EONConsulting\PackageStencil\Factories\WebServices;

/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/23/2016
 * Time: 11:52 AM
 */
class WebServiceEnum {

    const REST = 'REST';
    const SOAP = 'SOAP';

    /**
     * carry on the sequence if you need to add more WEB SERVICE TYPES here...
     */

    // const NEW_TYPE = 'NEW_TYPE';

}