<?php

/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/22/2016
 * Time: 11:31 AM
 */
class DummyJob
{

}