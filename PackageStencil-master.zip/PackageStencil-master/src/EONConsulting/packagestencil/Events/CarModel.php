<?php
/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/22/2016
 * Time: 3:32 PM
 */

namespace EONConsulting\PackageStencil\Events;


class CarModel extends Event {

    public $model;

    public function __construct() {
        parent::__construct();
        $this->model = "1975";
    }

}