<?php
/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/22/2016
 * Time: 3:18 PM
 */

namespace EONConsulting\PackageStencil\Events;


class SayHello extends Event {

    protected $name;

    public function __construct($name) {
        parent::__construct();
        $this->name = $name;
    }

    public function get_name() {
        return $this->name;
    }

    public function set_name($name) {
        if($this->name != $name) {
            $this->name = $name;
            $this->notify();
        }
    }

}