<?php

namespace EONConsulting\PackageStencil\Providers;

use EONConsulting\PackageStencil\PackageStencil;
use Illuminate\Support\ServiceProvider;

/**
 * Created by PhpStorm.
 * User: Josh Harington
 * Date: 11/22/2016
 * Time: 11:55 AM
 */
class PackageStencilServiceProvider extends ServiceProvider {

    /**
     * @return void
     */
    public function boot() {
        $this->loadViewsFrom(__DIR__.'/../Views', 'packagestencil');
    }

    /**
     *  Register the service provider
     */
    public function register() {
        $this->app->singleton('packagestencil', function($app) {
            return new PackageStencil;
        });
    }

}