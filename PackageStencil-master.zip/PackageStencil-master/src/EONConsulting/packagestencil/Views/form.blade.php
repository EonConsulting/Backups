<?php
echo 'This is the form view';
dd($hello_message);